// Firebase Configuration and Initialization
// 🔥 여기에 Firebase 설정을 입력하세요! 🔥

// ⚠️ 중요: 아래 firebaseConfig를 Firebase Console에서 복사한 내용으로 교체하세요!
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",  // ← Firebase Console에서 복사
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_ID",
  appId: "YOUR_APP_ID"
};

// Firebase 초기화
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

console.log('✅ Firebase 연결 완료!');

// Firestore 데이터베이스 설정
// 한국 시간대 설정
const TIMEZONE_OFFSET = 9 * 60 * 60 * 1000; // UTC+9 (한국)

// 컬렉션 이름 정의
const COLLECTIONS = {
    DEFECTS: 'defects',
    IMPORTS: 'imports'
};

// Firebase API 래퍼
const FirebaseAPI = {
    // ==================== 불량 데이터 관리 ====================
    
    // 모든 불량 데이터 조회
    async getDefects(params = {}) {
        try {
            console.log('📦 Firebase에서 불량 데이터 조회 중...');
            
            let query = db.collection(COLLECTIONS.DEFECTS);
            
            // 정렬 (최신순)
            query = query.orderBy('created_at', 'desc');
            
            // limit 적용
            if (params.limit) {
                query = query.limit(parseInt(params.limit));
            }
            
            const snapshot = await query.get();
            const data = [];
            
            snapshot.forEach(doc => {
                data.push({
                    id: doc.id,
                    ...doc.data()
                });
            });
            
            console.log(`✅ 불량 데이터 ${data.length}개 조회 완료`);
            
            return {
                data: data,
                total: data.length,
                page: 1,
                limit: params.limit || 1000
            };
        } catch (error) {
            console.error('❌ Firebase 조회 오류:', error);
            throw new Error('데이터를 불러오는데 실패했습니다.');
        }
    },
    
    // 단일 불량 데이터 조회
    async getDefect(id) {
        try {
            const doc = await db.collection(COLLECTIONS.DEFECTS).doc(id).get();
            
            if (!doc.exists) {
                throw new Error('데이터를 찾을 수 없습니다.');
            }
            
            return {
                id: doc.id,
                ...doc.data()
            };
        } catch (error) {
            console.error('❌ Firebase 조회 오류:', error);
            throw error;
        }
    },
    
    // 불량 데이터 생성
    async createDefect(data) {
        try {
            console.log('💾 Firebase에 불량 데이터 저장 중...');
            
            // 생성 시간 추가
            const timestamp = Date.now();
            const defectData = {
                ...data,
                created_at: timestamp,
                updated_at: timestamp
            };
            
            const docRef = await db.collection(COLLECTIONS.DEFECTS).add(defectData);
            
            console.log(`✅ 불량 데이터 저장 완료 (ID: ${docRef.id})`);
            
            return {
                id: docRef.id,
                ...defectData
            };
        } catch (error) {
            console.error('❌ Firebase 저장 오류:', error);
            throw new Error('데이터 저장에 실패했습니다.');
        }
    },
    
    // 불량 데이터 수정
    async updateDefect(id, data) {
        try {
            console.log(`📝 Firebase 불량 데이터 수정 중... (ID: ${id})`);
            
            const updateData = {
                ...data,
                updated_at: Date.now()
            };
            
            await db.collection(COLLECTIONS.DEFECTS).doc(id).update(updateData);
            
            console.log('✅ 불량 데이터 수정 완료');
            
            return {
                id: id,
                ...updateData
            };
        } catch (error) {
            console.error('❌ Firebase 수정 오류:', error);
            throw new Error('데이터 수정에 실패했습니다.');
        }
    },
    
    // 불량 데이터 삭제
    async deleteDefect(id) {
        try {
            console.log(`🗑️ Firebase 불량 데이터 삭제 중... (ID: ${id})`);
            
            await db.collection(COLLECTIONS.DEFECTS).doc(id).delete();
            
            console.log('✅ 불량 데이터 삭제 완료');
            
            return true;
        } catch (error) {
            console.error('❌ Firebase 삭제 오류:', error);
            throw new Error('데이터 삭제에 실패했습니다.');
        }
    },
    
    // ==================== 수입 물량 관리 ====================
    
    // 모든 수입 물량 조회
    async getImports(page = 1, limit = 100) {
        try {
            console.log('📦 Firebase에서 수입 물량 조회 중...');
            
            const query = db.collection(COLLECTIONS.IMPORTS)
                .orderBy('import_date', 'desc')
                .limit(limit);
            
            const snapshot = await query.get();
            const data = [];
            
            snapshot.forEach(doc => {
                data.push({
                    id: doc.id,
                    ...doc.data()
                });
            });
            
            console.log(`✅ 수입 물량 ${data.length}개 조회 완료`);
            
            return {
                data: data,
                total: data.length,
                page: page,
                limit: limit
            };
        } catch (error) {
            console.error('❌ Firebase 조회 오류:', error);
            throw new Error('수입 물량 데이터를 불러오는데 실패했습니다.');
        }
    },
    
    // 단일 수입 물량 조회
    async getImport(id) {
        try {
            const doc = await db.collection(COLLECTIONS.IMPORTS).doc(id).get();
            
            if (!doc.exists) {
                throw new Error('데이터를 찾을 수 없습니다.');
            }
            
            return {
                id: doc.id,
                ...doc.data()
            };
        } catch (error) {
            console.error('❌ Firebase 조회 오류:', error);
            throw error;
        }
    },
    
    // LOT 번호로 수입 물량 조회
    async getImportByLot(lotNumber) {
        try {
            const snapshot = await db.collection(COLLECTIONS.IMPORTS)
                .where('lot_number', '==', lotNumber)
                .limit(1)
                .get();
            
            if (snapshot.empty) {
                return null;
            }
            
            const doc = snapshot.docs[0];
            return {
                id: doc.id,
                ...doc.data()
            };
        } catch (error) {
            console.error('❌ Firebase 조회 오류:', error);
            return null;
        }
    },
    
    // 수입 물량 생성
    async createImport(data) {
        try {
            console.log('💾 Firebase에 수입 물량 저장 중...');
            
            const timestamp = Date.now();
            const importData = {
                ...data,
                created_at: timestamp,
                updated_at: timestamp
            };
            
            const docRef = await db.collection(COLLECTIONS.IMPORTS).add(importData);
            
            console.log(`✅ 수입 물량 저장 완료 (ID: ${docRef.id})`);
            
            return {
                id: docRef.id,
                ...importData
            };
        } catch (error) {
            console.error('❌ Firebase 저장 오류:', error);
            throw new Error('수입 물량 저장에 실패했습니다.');
        }
    },
    
    // 수입 물량 수정
    async updateImport(id, data) {
        try {
            console.log(`📝 Firebase 수입 물량 수정 중... (ID: ${id})`);
            
            const updateData = {
                ...data,
                updated_at: Date.now()
            };
            
            await db.collection(COLLECTIONS.IMPORTS).doc(id).update(updateData);
            
            console.log('✅ 수입 물량 수정 완료');
            
            return {
                id: id,
                ...updateData
            };
        } catch (error) {
            console.error('❌ Firebase 수정 오류:', error);
            throw new Error('수입 물량 수정에 실패했습니다.');
        }
    },
    
    // 수입 물량 삭제
    async deleteImport(id) {
        try {
            console.log(`🗑️ Firebase 수입 물량 삭제 중... (ID: ${id})`);
            
            await db.collection(COLLECTIONS.IMPORTS).doc(id).delete();
            
            console.log('✅ 수입 물량 삭제 완료');
            
            return true;
        } catch (error) {
            console.error('❌ Firebase 삭제 오류:', error);
            throw new Error('수입 물량 삭제에 실패했습니다.');
        }
    }
};

// 기존 API를 FirebaseAPI로 교체
window.API = FirebaseAPI;

console.log('🔥 Firebase API 준비 완료!');
